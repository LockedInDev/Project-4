let buffer = '0';
let runningTotal = 0;
let previousOperator = null;

const answer = document.querySelector('.answer');

function buttonClick(value) {
    if (isNaN(parseInt(value))) { // value is NaN handle with Symbol
        handleSymbol(value);
    } else {
        handleNumber(value); // handles numbers
    }
    rerender();
}

function handleNumber(number) {
    if (buffer === '0') { //if buffer is === 0, replaces it with a number(0)
        buffer = number;
    } else {
        buffer += number;
    }
    console.log(buffer);
}

function handleMath(value) {
    if (buffer === '0') {
        // does nothing
        return;
    }

    const intBuffer = parseInt(buffer);
    if (runningTotal === 0) {
        runningTotal = intBuffer;
    } else {
        flushOperation(intBuffer);
    }

    previousOperator = value;
    buffer = '0';
    console.log(runningTotal);
}

function flushOperation(intBuffer) {
    switch (previousOperator) {
        case '+':
            runningTotal += intBuffer;
            break;
        case '–':
            runningTotal -= intBuffer;
            break;
        case '×':
            runningTotal *= intBuffer;
            break;
        case '÷':
            runningTotal /= intBuffer;
            break;
    }

}

function handleSymbol(symbol) {
    switch (symbol) {
        case 'C':
            buffer = '0';
            break;
        case '=':
            if (previousOperator === null) {
                //need two numbers to do math
                return;
            }
            flushOperation(parseInt(buffer));
            previousOperator = null;
            buffer = "" + runningTotal;
            runningTotal = 0;

            break;
        case '←':
            if (buffer.length === 1) {
                buffer = '0';
            } else {
                buffer = buffer.substring(0, buffer.length - 1);
            }
            break;
        case '+':
        case '–':
        case '÷':
        case '×':
            handleMath(symbol);
            break;
        case 'Enter':
            buttonClick('=');
            break;
        case '/':
            buttonClick('÷');
            break;
        case '*':
            buttonClick('×');
            break;
        case '-':
            buttonClick('–');
            break;
        case '+':
            buttonClick('+');
            break;
    }
}

function init() { // initializes code and needs to be called
    console.log("hi");
    document
        .querySelector('.calc-buttons') // Finds .calc-buttons
        .addEventListener("click", function (event) { // when someone clicks it runs functions
            buttonClick(event.target.innerText); // targets whatever div that is clicked and targets the text of the button
        });

    // Add event listener for numpad
    window.addEventListener('keydown', (event) => {
        const { key } = event;
        switch (key) {
            case 'Enter':
            case '/':
            case '*':
            case '-':
            case '+':
                handleSymbol(key);
                break;
            default:
                buttonClick(key);
        }
    });
}

function rerender() {
    answer.innerText = buffer;
}

init(); // calls code
